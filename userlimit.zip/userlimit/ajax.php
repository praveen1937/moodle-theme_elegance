<?php
define('AJAX_SCRIPT', true);
require_once(dirname(__FILE__).'/../../config.php');
require_once($CFG->dirroot.'/local/userlimit/locallib.php');
global $DB;
$type = optional_param('type','',PARAM_RAW);
$roleid = optional_param('roleid',0,PARAM_INT);
$userid = optional_param('userid',0,PARAM_INT);
require_login();

$users = array();
$userlimit = 0;
if($type == 'role'){
	if($roleid > 0){
		$allusers = local_userlimit_getusers_by_role($roleid);
		foreach($allusers as $user) {
			$userobj = $DB->get_record('user', array('id' => $user->id));
			$users[] = array('id' =>$user->id, 'username' => fullname($userobj));
		}
		$select = array('id' => 0, 'username' => get_string('select_user', 'local_userlimit'));
		array_unshift($users, $select);
	}
} else if($type == 'user'){
	if($roleid > 0 && $userid > 0){
		$rsuserlimit = $DB->get_record('local_userlimit', array('roleid' => $roleid, 'userid' => $userid));
		if($rsuserlimit){
			$userlimit = $rsuserlimit->userlimit;
		}
	}
}
echo json_encode(['users' => $users,'userlimit' => $userlimit]);