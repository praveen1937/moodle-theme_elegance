<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local plugin "userlimit" - Language pack English
 * 
 * @package   local_userlimit
 * @author    Praveen Charles
 * @copyright 2020 <aruncharles1937@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'Kullanıcı Sınırı';
$string['access_denied'] = 'Erişim reddedildi. Lütfen site yöneticisine başvurun!';
$string['userlimit_form_intro'] = 'Bu sayfa, istemcinin sisteme ekleyebileceği maksimum kullanıcı sınırını ayarlamak için kullanılır.';
$string['user_limit'] = 'Kullanıcı sınırı';
$string['userlimit'] = 'Kullanıcı sınırı';
$string['userlimit_help'] = 'Site yöneticisi hariç diğer yöneticiler tarafından oluşturulabilecek toplam izin verilen kullanıcı sayısı.';
$string['user_limit_header'] = 'Kullanıcı sınır formu';
$string['submit'] = 'Sunmak';
$string['error_user_limit_empty'] = 'Kullanıcı sınırı boş. Lütfen sayısal değer girin';
$string['error_user_limit_invalid'] = 'Kullanıcı sınırı geçersiz. Lütfen sayısal değer girin';
$string['success_userlimit'] = 'Kullanıcı sınırı başarıyla güncellendi!';
$string['failed_userlimit'] = 'İşlenemiyor. Lütfen tekrar deneyin!';
$string['sno'] = 'hayır';
$string['createdby'] = 'Tarafından yaratıldı';
$string['timecreated'] = 'Oluşturma Zamanı';
$string['total_users'] = 'Toplam oluşturulan kullanıcı';
$string['error_user_limit_reached'] = 'Kullanıcı sınırına ulaşıldı. Lütfen site yöneticisine başvurun!';
$string['success_delete'] = 'Kayıt başarıyla silindi!';
$string['failed_delete'] = 'Silinemiyor. Lütfen tekrar deneyin!';
$string['no_records_found'] = 'Kayıt bulunamadı!';
$string['role_name'] = 'Rol ismi';
$string['user_name'] = 'Kullanıcı tam adı';
$string['action'] = 'Aksiyon';
$string['error_valid_limit_adduser'] = 'Kullanıcı sınırına ulaşıldı. Lütfen site yöneticisine başvurun !. 
										Toplam kullanıcı sınırı {$a->userlimit}. Kullanılabilir kullanıcılar {$a->totalusers}.';
$string['error_valid_limit_uploaduser'] = 'Kullanıcı sınırına ulaşıldı. Lütfen site yöneticisine başvurun !.
											Toplam kullanıcı sınırı {$a->userlimit}. Kullanılabilir kullanıcılar {$a->totalusers}.
											İzin verilen kullanıcılar {$a->potentialusercount}';
$string['select_role'] = 'Rol Seçin';
$string['select_user'] = 'Kullanıcı seç';
$string['createusersubject'] = 'Yeni kullanıcı oluşturuldu {$a->sitename}';
$string['uploadusersubject'] = 'Yeni kullanıcı yüklendi {$a->sitename}';
$string['createuserbody'] = 'Selam {$a->adminname},
{$a->usercreatedcount} kullanıcı hesabı şu saatte oluşturuldu: \'{$a->sitename}\' 
kullanıcı sınırı ayrıntıları:
Yönetici ismi : {$a->managername}
Toplam Kullanıcı sınırı : {$a->totaluserlimits}
Oluşturulan kullanıcılar : {$a->totalcreatedusers}
Mevcut kullanıcılar : {$a->availableusers}
Teşekkürler.';
$string['messageprovider:userlimit_user_registration'] = 'Kullanıcı sınırı kullanıcı kayıt bildirimi';
$string['number_of_deleted_users'] = 'Silinen Kullanıcı Sayısı';
$string['number_of_active_users'] = 'Aktif Kullanıcı Sayısı';