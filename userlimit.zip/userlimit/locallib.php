<?php
function local_userlimit_updatelimit($data) {
	global $DB, $USER;
	$id = $data->id;
	$limitdata = new stdclass();
	$limitdata->userlimit = $data->userlimit;
	$limitdata->roleid = $data->role;
	$limitdata->userid = $data->user;
	$limitdata->timemodified = time();
	$limitdata->modifiedby = $USER->id;
	if($id > 0){
		$rslimit = $DB->get_record('local_userlimit', array('id' => $id));
		$limitdata->id = $rslimit->id;
		$DB->update_record('local_userlimit', $limitdata);
	} else {
		$limitdata->timecreated = time();
		$limitdata->createdby = $USER->id;
		$id = $DB->insert_record('local_userlimit', $limitdata);
	}
	return $id;
}

function render_userlimit_logs() {
	global $PAGE, $CFG, $DB, $OUTPUT;
	
	$userlimtlogs = $DB->get_records('local_userlimit',array(), 'id desc');
	$data = render_userlimit_logs_data($userlimtlogs);
	$table = new html_table();
	$tableheader = array(get_string('sno', 'local_userlimit'),
							get_string('role_name', 'local_userlimit'),
							get_string('user_name', 'local_userlimit'),
							get_string('user_limit', 'local_userlimit'),
							get_string('createdby', 'local_userlimit'),
							get_string('timecreated', 'local_userlimit'),
							get_string('action', 'local_userlimit')
						);
	$table->head = $tableheader;
	$table->size = array('5%', '15%', '20%', '10%', '20%', '20%','10');
	$table->align = array('center', 'center', 'left', 'left', 'center');
	$table->width = '80%';
	$table->id = 'userlimit';
	if(count($userlimtlogs) > 0){
		$table->data = $data;
	} else {
		$cell = new html_table_cell();
		$cell->text = get_string('no_records_found', 'local_userlimit');
		$cell->colspan = 7;
		$row = new html_table_row();
		$row->cells[] = $cell;
		$table->data = array($row);
		$table->align = array('center');
	}
	$output = html_writer::table($table);
	return $output;
}

function render_userlimit_logs_data($userlimts) {
	global $DB, $OUTPUT;
	$data = array();
	$i=1;
	foreach($userlimts as $userlimit) {
		$buttons = array();
		$userfullname = '-';
		$createdtime = '-';
		$createduser = '-';
		$rolename = '-';
		if($userlimit->userid > 0) {
			$userdetails = $DB->get_record('user', array('id' => $userlimit->userid));
			$userfullname = fullname($userdetails);
		}
		if($userlimit->timecreated > 0) {
			$createdtime = date('Y-m-d H:i:s', $userlimit->timecreated);
		}
		if($userlimit->createdby > 0) {
			$userdetails1 = $DB->get_record('user', array('id' => $userlimit->createdby));
			$createduser = fullname($userdetails1);
		}
		if($userlimit->roleid > 0){
			$rolename = $DB->get_field('role', 'shortname',array('id' => $userlimit->roleid));
		}
		$editurl = new moodle_url($CFG->wwwroot.'/local/userlimit/index.php', array('id' => $userlimit->id));
		$delete = new moodle_url($CFG->wwwroot.'/local/userlimit/index.php', array('delete' => $userlimit->id));
		$actionicons = html_writer::link($editurl, html_writer::empty_tag('img', array('src' => $OUTPUT->image_url('i/edit'),
													'title' => 'Edit', 'class' => 'iconsmall', 'width' => '16', 'height' => '16')));
		$actionicons .= html_writer::link($delete, html_writer::empty_tag('img', array('src' => $OUTPUT->image_url('i/delete'),
											'title' => 'Delete', 'class' => 'iconsmall', 'width' => '16', 'height' => '16')));
		
        $buttons[] = html_writer::link($editurl, $OUTPUT->pix_icon('t/edit', 'Edit'));
        $buttons[] = html_writer::link($delete, $OUTPUT->pix_icon('t/delete', 'Delete'));
		$row = array($i++, 
					$rolename, 
					$userfullname, 
					$userlimit->userlimit,
					$createduser,
					$createdtime,
					implode(' ', $buttons)
					);
		$data[] = $row;
	}
	return $data;
}

function local_userlimit_getusers_by_role($roleid){
	global $DB;
	$sql = "select u.id from {user} u inner join {role_assignments} ra on u.id = ra.userid 
			where ra.roleid = {$roleid} order by u.firstname asc";
	$allusers = $DB->get_records_sql($sql);
	return $allusers;
}

function local_userlimit_delete($id){
	global $DB;
	if($DB->delete_records('local_userlimit', array('id' => $id))){
		return true;
	} else {
		return false;
	}
}

function local_userlimit_checkvalidation($data = array(), $id=0) {
	global $DB, $USER;
	$sql = "select * from {local_userlimit} where userid = {$USER->id} order by id asc limit 1";
	$rslimit = $DB->get_record_sql($sql);
	$totalusers = $DB->count_records('user');
	if(count($data) == 0){
		$userlimit = 0;
		if($rslimit){
			$userlimit = $rslimit->userlimit;
		}
		if($userlimit > 0 && $totalusers >= $userlimit && $id==-1) {
			print_error(get_string('error_valid_limit_adduser', 'local_userlimit', ['userlimit' => $userlimit, 'totalusers' => $totalusers]));
		}
	} else {
		$uploadedusers = count($data);
		$totalusercount = $totalusers + $uploadedusers;
		$userlimit = 0;
		if($rslimit){
			$userlimit = $rslimit->userlimit;
		}
		$potentialusercount = $userlimit - $totalusers;
		if($potentialusercount < 0){
			$potentialusercount = 0;
		}
		if($userlimit > 0 && $totalusercount >= $userlimit) {
			print_error(get_string('error_valid_limit_uploaduser', 'local_userlimit', 
								['userlimit' => $userlimit, 'totalusers' => $totalusers, 'potentialusercount' => $potentialusercount]));
		}
	}
}

function local_userlimit_send_email($usercount) {
	global $DB, $USER;
	
	$sql = "select * from {local_userlimit} where userid = {$USER->id} order by id asc limit 1";
	$rslimit = $DB->get_record_sql($sql);
	$totalusers = $DB->count_records('user');
	$userlimit = 0;
	if($rslimit){
		$userlimit = $rslimit->userlimit;
	}
	$potentialusercount = $userlimit - $totalusers;
	if($potentialusercount < 0){
		$potentialusercount = 0;
	}
	
	$site = get_site();
	$admin = get_admin();
	$data['sitename'] = format_string($site->fullname);
	$data['adminname'] = fullname($admin);
	$data['managername'] = fullname($USER);
	$data['totaluserlimits'] = $userlimit;
	$data['totalcreatedusers'] = $totalusers;
	$data['availableusers'] = $potentialusercount;
	$data['usercreatedcount'] = $usercount;
	$subject  = get_string('uploadusersubject', 'local_userlimit', $data);
	
	$message  = get_string('createuserbody', 'local_userlimit', $data);
	$messagehtml = text_to_html($message, false, false, true);
	
	$admin = get_admin();
	$fromuser = $DB->get_record("user", array("id" => $USER->id));
	return email_to_user($admin, $fromuser, $subject, $message, $messagehtml);
	/*$alladmins = get_admins();
	foreach($alladmins as $supportuser){
		return email_to_user($supportuser, $supportuser, $subject, $message, $messagehtml);
	}
	*/
}