<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local plugin "userlimit" - User limit page
 *
 * @package   local_userlimit
 * @author    Praveen Charles
 * @copyright 2020 <aruncharles1937@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


namespace local_userlimit;

use moodleform;

defined('MOODLE_INTERNAL') || die();

global $CFG;

require_once($CFG->libdir.'/formslib.php');
require_once($CFG->dirroot . '/' . $CFG->admin . '/roles/lib.php');
/**
 * Local plugin "userlimit" - User limit page
 *
 * @package   local_userlimit
 * @author    Praveen Charles
 * @copyright 2020 <aruncharles1937@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

class userlimit_form extends moodleform {

    /**
     * Form definition. Abstract method - always override!
     */
    protected function definition() {
        global $CFG, $DB;

        $id = $this->_customdata['id'];
		$userlimit = 0;
		$roleid = 0;
		$userid = 0;
		
		if($id > 0){
			$rsuserlimit = $DB->get_record('local_userlimit',array('id' => $id));
			if($rsuserlimit) {
				$roleid = $rsuserlimit->roleid;
				$userlimit = $rsuserlimit->userlimit;
				$userid = $rsuserlimit->userid;
			}
		}
		
		list($context, $course, $cm) = get_context_info_array($contextid=1);
		list($assignableroles, $assigncounts, $nameswithcounts) = get_assignable_roles($context, ROLENAME_BOTH, true);
		
		
		$roles = array();
		$roles[''] = get_string('select_role','local_userlimit');
		foreach($assignableroles as $key=>$val) {
			$roles[$key] = $val;
		}
		
		$users = array();
		$users[''] = 'Select User';
		if($roleid > 0){
			$allusers = local_userlimit_getusers_by_role($roleid);
			foreach($allusers as $user) {
				$userobj = $DB->get_record('user', array('id' => $user->id));
				$users[$user->id] = fullname($userobj);
			}
		}
		
		$activeusers = $DB->count_records('user',array('deleted' => 0));
		$deletedusers = $DB->count_records('user',array('deleted' => 1));
		
		$mform = $this->_form;
		$mform->addElement('header','userlimitheader', get_string('user_limit_header', 'local_userlimit'), '');
        // Infotext.
        $msg = get_string('userlimit_form_intro', 'local_userlimit');
        $mform->addElement('html', '<div id="intro">'.$msg.'</div>');
		 
		$mform->addElement('static', 'deletedusers', get_string('number_of_deleted_users', 'local_userlimit'),$deletedusers);
		$mform->addElement('static', 'activeusers', get_string('number_of_active_users', 'local_userlimit'),$activeusers);

		$mform->addElement('select', 'role',
                get_string('select_role', 'local_userlimit'), $roles);
		$mform->setDefault('role', $roleid);
		$mform->addRule('role', null, 'required', 'client');
		
		
		$mform->addElement('select', 'user',
                get_string('select_user', 'local_userlimit'), $users);
		$mform->setDefault('user', $userid);
		$mform->addRule('user', null, 'required', 'client');
		
        $mform->addElement('text', 'userlimit',
                get_string('user_limit', 'local_userlimit'), 'maxlenght="6" size="25"');
        $mform->addRule('userlimit', null, 'required', 'client');
        $mform->addHelpButton('userlimit', 'userlimit', 'local_userlimit');
		$mform->setType('userlimit', PARAM_RAW);
		$mform->setDefault('userlimit',$userlimit);
        
        $mform->addElement('hidden', 'id');
        $mform->setType('id', PARAM_INT);
        $mform->setDefault('id', $id);

        $this->add_action_buttons(true, get_string('submit', 'local_userlimit'));
    }

    /**
     * Get each of the rules to validate its own fields
     *
     * @param array $data array of ("fieldname"=>value) of submitted data
     * @param array $files array of uploaded files "element_name"=>tmp_file_path
     * @return array of "element_name"=>"error_description" if there are errors,
     *         or an empty array if everything is OK (true allowed for backwards compatibility too).
     */
    public function validation($data, $files) {
        $retval = array();

        if (empty($data['userlimit'])) {
            $retval['userlimit'] = get_string('error_user_limit_empty', 'local_userlimit');
        } else if(!is_numeric($data['userlimit'])){
			$retval['userlimit'] = get_string('error_user_limit_invalid', 'local_userlimit');
		}

        return $retval;
    }
}
