<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local plugin "userlimit" - User limit page
 *
 * @package   local_userlimit
 * @author    Praveen Charles
 * @copyright 2020 <aruncharles1937@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use local_userlimit\userlimit_form;

require_once('../../config.php');

require_once($CFG->dirroot.'/local/userlimit/locallib.php');

global $PAGE, $OUTPUT, $SESSION;

$id = optional_param('id', 0, PARAM_INT);
$delete = optional_param('delete', 0, PARAM_INT);

$context = context_system::instance();
require_login();
if(!is_siteadmin()){
	print_error(get_string('access_denied','local_userlimit'));
}
$url = new moodle_url($CFG->wwwroot.'/local/userlimit/index.php', array('id' => $id));
$context = context_system::instance();

$PAGE->set_context($context);
$PAGE->set_url($url);
$PAGE->set_pagelayout('admin');
$PAGE->set_title(get_string('pluginname','local_userlimit'));
$PAGE->set_heading(get_string('pluginname','local_userlimit'));
$PAGE->navbar->add(get_string('pluginname','local_userlimit'), $url, navigation_node::TYPE_SETTING );
$PAGE->requires->jquery();

if($delete > 0){
	$return = local_userlimit_delete($delete);
	if($return == true){
		$msg = get_string('success_delete','local_userlimit');
	} else {
		$msg = get_string('failed_delete','local_userlimit');
	}
	$urlredirect = new moodle_url($CFG->wwwroot.'/local/userlimit/index.php');
	redirect($urlredirect, $msg, 3);
}

$args = array('id' => $id);
$mform = new userlimit_form(null, $args);
if ($mform->is_cancelled()) {
} else if ($mform->get_data()) {
	$formdata = data_submitted();
	$return = local_userlimit_updatelimit($formdata);
	if($return == true){
		$msg = get_string('success_userlimit','local_userlimit');
	} else {
		$msg = get_string('failed_userlimit','local_userlimit');
	}
	$urlredirect = new moodle_url($CFG->wwwroot.'/local/userlimit/index.php', array('id' => $id));
	redirect($urlredirect, $msg, 3);
} else {
	echo $OUTPUT->header();
	echo $mform->display();
	$list = render_userlimit_logs();
	echo $list;
	echo $OUTPUT->footer();
	?>
	<script>
		$(document).ready(function() {
			$('#id_role').on('change', function() {
				var roleid = $('#id_role').val();
				var template = '';
				$.ajax({
					method : "GET",
					dataType : "json",
					url : "ajax.php?type=role&roleid="+roleid,
					success: function(data) {
						$.each(data.users, function(index, value) {
							template += "<option value = "+value.id+" >" +value.username + "</option>";
						});
						$("#id_user").html(template);
					}
				});
			});
			$('#id_user').on('change', function() {
				var roleid = $('#id_role').val();
				var userid = $('#id_user').val();
				var template = '';
				$.ajax({
					method : "GET",
					dataType : "json",
					url : "ajax.php?type=user&roleid="+roleid+"&userid="+userid,
					success: function(data) {
						$("#id_userlimit").val(data.userlimit)
					}
				});
			});
		});
	</script>
<?php }