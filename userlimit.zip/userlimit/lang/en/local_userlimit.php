<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local plugin "userlimit" - Language pack English
 * 
 * @package   local_userlimit
 * @author    Praveen Charles
 * @copyright 2020 <aruncharles1937@gmail.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['pluginname'] = 'User Limit';
$string['access_denied'] = 'Access denied. Please contact site administrator!';
$string['userlimit_form_intro'] = 'This page is used to set up the maximum user limt the client can add into the system.';
$string['user_limit'] = 'User limit';
$string['userlimit'] = 'User limit';
$string['userlimit_help'] = 'The total number allowed users that can be created by other managers except site administrator.';
$string['user_limit_header'] = 'User limit form';
$string['submit'] = 'Submit';
$string['error_user_limit_empty'] = 'User limit is empty. Please enter numeric value';
$string['error_user_limit_invalid'] = 'User limit is invalid. Please enter numeric value';
$string['success_userlimit'] = 'User limit updated successfully!';
$string['failed_userlimit'] = 'Unable to process. Please try again!';
$string['sno'] = 'S.No';
$string['createdby'] = 'Created By';
$string['timecreated'] = 'Created Time';
$string['total_users'] = 'Total created users';
$string['error_user_limit_reached'] = 'User limit reached. Please contact site administrator!';
$string['success_delete'] = 'Record deleted successfully!';
$string['failed_delete'] = 'Unable to delete. Please try again!';
$string['no_records_found'] = 'No records found!';
$string['role_name'] = 'Role name';
$string['user_name'] = 'User full name';
$string['action'] = 'Action';
$string['error_valid_limit_adduser'] = 'User limit reached. Please contact site administrator!. 
										Total user limit is {$a->userlimit}. Available users {$a->totalusers}.';
$string['error_valid_limit_uploaduser'] = 'User limit reached. Please contact site administrator!. 
										Total user limit is {$a->userlimit}. Available users {$a->totalusers}.
										Allowed users {$a->potentialusercount}';
$string['select_role'] = 'Select Role';
$string['select_user'] = 'Select User';
$string['createusersubject'] = 'New user created {$a->sitename}';
$string['uploadusersubject'] = 'New users uploaded {$a->sitename}';
$string['createuserbody'] = 'Hi {$a->adminname},
{$a->usercreatedcount} user account(s) has been created at \'{$a->sitename}\' 
user limit details:
Manager Name : {$a->managername}
Total User limit : {$a->totaluserlimits}
Users created: {$a->totalcreatedusers}
Available users: {$a->availableusers}
Thanks.';
$string['messageprovider:userlimit_user_registration'] = 'Userlimit user registration notification';
$string['number_of_deleted_users'] = 'Number of Deleted Users';
$string['number_of_active_users'] = 'Number of Active Users';